mv -v aq13.pg q13.pg
mv -v aq14.pg q14.pg
mv -v aq15.pg q15.pg
mv -v aq16.pg q16.pg
mv -v aq17.pg q17.pg
mv -v aq18.pg q18.pg
mv -v aq19.pg q19.pg
mv -v aq20.pg q20.pg
mv -v aq21.pg q21.pg
mv -v aq22.pg q22.pg
mv -v aq23.pg q23.pg

