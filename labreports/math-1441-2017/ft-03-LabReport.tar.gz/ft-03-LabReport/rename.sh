mv -v aq01.pg q01.pg
mv -v aq02.pg q02.pg
mv -v aq03.pg q03.pg
mv -v aq04.pg q04.pg
mv -v aq05.pg q05.pg
mv -v aq06.pg q06.pg
mv -v aq07.pg q07.pg
mv -v aq08.pg q08.pg
mv -v aq09.pg q09.pg
mv -v aq10.pg q10.pg
mv -v aq11.pg q11.pg
mv -v aq12.pg q12.pg
mv -v aq13.pg q13.pg
mv -v aq14.pg q14.pg

