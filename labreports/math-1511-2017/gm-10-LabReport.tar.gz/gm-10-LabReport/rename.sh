mv -v q03.pg q-07-03.pg
mv -v q04.pg q-07-04.pg
mv -v q05.pg q-07-05.pg
mv -v q06.pg q-07-06.pg
mv -v q07.pg q-07-07.pg
mv -v q08.pg q-07-08.pg
mv -v q09.pg q-07-09.pg
